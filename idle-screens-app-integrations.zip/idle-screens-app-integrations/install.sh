#!/usr/bin/env bash
set -euo pipefail
APP_DIR=${1:-/opt/idle-screens-app}
PYTHON_BIN=${PYTHON_BIN:-python3}

echo "Installing Idle Screens to ${APP_DIR}"
sudo apt update
sudo apt install -y python3 python3-venv python3-pip
sudo mkdir -p "$APP_DIR"
sudo rsync -a ./ "$APP_DIR"/
cd "$APP_DIR"
$PYTHON_BIN -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
cp -n .env.example .env || true
chmod +x run.sh

echo
cat <<EOF
Install complete.

Run it with:
  cd $APP_DIR
  ./run.sh

Then open:
  http://SERVER-IP:8008/
EOF
