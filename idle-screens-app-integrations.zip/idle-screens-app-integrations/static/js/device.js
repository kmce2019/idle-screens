const root = document.getElementById('device-app');
const device = window.IDLE_SCREENS_DEVICE;

let payload = null;
let currentIndex = 0;
let timer = null;
let photoIndex = 0;

async function fetchPayload() {
  const res = await fetch(`/api/device/${device.slug}`);
  if (!res.ok) throw new Error('Could not load device payload');
  payload = await res.json();
}

function formatTime(showSeconds = false, timezone = 'America/Chicago') {
  return new Intl.DateTimeFormat([], {
    hour: 'numeric', minute: '2-digit', second: showSeconds ? '2-digit' : undefined,
    hour12: true, timeZone: timezone
  }).format(new Date());
}

function formatDate(timezone = 'America/Chicago') {
  return new Intl.DateTimeFormat([], {
    weekday: 'long', month: 'long', day: 'numeric', timeZone: timezone
  }).format(new Date());
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function renderClock(item) {
  const timezone = item.config.timezone || 'America/Chicago';
  const showSeconds = !!item.config.show_seconds;
  root.innerHTML = `
    <div class="screen">
      <div class="kicker">${escapeHtml(item.title)}</div>
      <div class="big-time" id="clock-time"></div>
      <div class="big-date">${item.config.show_date === false ? '' : escapeHtml(formatDate(timezone))}</div>
    </div>`;
  const tick = () => {
    const el = document.getElementById('clock-time');
    if (el) el.textContent = formatTime(showSeconds, timezone);
  };
  tick();
  const interval = setInterval(tick, 1000);
  return () => clearInterval(interval);
}

function renderCustomText(item) {
  root.innerHTML = `
    <div class="screen">
      <div class="kicker">${escapeHtml(item.title)}</div>
      <div class="big-body">${escapeHtml(item.config.body || '')}</div>
      ${item.config.subtext ? `<div class="big-subtext">${escapeHtml(item.config.subtext)}</div>` : ''}
    </div>`;
}

function renderQuote(item) {
  const quote = item.config.selected_quote || 'No quote configured.';
  root.innerHTML = `
    <div class="screen">
      <div class="kicker">${escapeHtml(item.title)}</div>
      <div class="quote-text">“${escapeHtml(quote)}”</div>
    </div>`;
}

function renderPhotos(item, useNas = false) {
  const source = item.config.photos || ((item.config.live || {}).photos) || [];
  if (!source.length) {
    root.innerHTML = `<div class="screen"><div class="big-title">No photos available</div></div>`;
    return;
  }
  const photo = source[photoIndex % source.length];
  photoIndex += 1;
  root.innerHTML = `
    <div class="screen">
      <div class="kicker">${escapeHtml(item.title)}</div>
      <div class="photo-stage"><img src="${photo.url}" alt="${escapeHtml(photo.title || 'Photo')}"></div>
      <div class="footer-note">${escapeHtml(photo.title || (useNas ? 'NAS photo' : 'Photo'))}</div>
    </div>`;
}

function renderOpenWeather(item) {
  const live = item.config.live || {};
  if (!live.ok) {
    root.innerHTML = `<div class="screen"><div class="kicker">${escapeHtml(item.title)}</div><div class="big-title">Weather unavailable</div><div class="big-subtext">${escapeHtml(live.message || 'Configure OpenWeather in Settings.')}</div></div>`;
    return;
  }
  root.innerHTML = `
    <div class="screen">
      <div class="kicker">${escapeHtml(item.title)}</div>
      <div class="weather-grid">
        <div class="big-title">${escapeHtml(live.label)}</div>
        <div class="weather-temp">${escapeHtml(live.temp)}°</div>
        <div class="weather-meta">${escapeHtml(live.summary)} · Feels ${escapeHtml(live.feels_like)}° · Wind ${escapeHtml(live.wind)} mph · Humidity ${escapeHtml(live.humidity)}%</div>
      </div>
    </div>`;
}

function renderCalendar(item) {
  const live = item.config.live || {};
  if (!live.ok) {
    root.innerHTML = `<div class="screen"><div class="kicker">${escapeHtml(item.title)}</div><div class="big-title">Calendar unavailable</div><div class="big-subtext">${escapeHtml(live.message || 'Configure Calendar in Settings.')}</div></div>`;
    return;
  }
  const events = live.events || [];
  root.innerHTML = `
    <div class="screen">
      <div class="kicker">${escapeHtml(item.title)}</div>
      <div class="list-block">
        ${events.length ? events.map(ev => `<div class="list-row"><div class="list-title">${escapeHtml(ev.summary)}</div><div class="list-sub">${escapeHtml(ev.start)}${ev.location ? ' · ' + escapeHtml(ev.location) : ''}</div></div>`).join('') : '<div class="big-subtext">No upcoming events.</div>'}
      </div>
    </div>`;
}

function renderQbit(item) {
  const live = item.config.live || {};
  if (!live.ok) {
    root.innerHTML = `<div class="screen"><div class="kicker">${escapeHtml(item.title)}</div><div class="big-title">qBittorrent unavailable</div><div class="big-subtext">${escapeHtml(live.message || 'Configure qBittorrent in Settings.')}</div></div>`;
    return;
  }
  root.innerHTML = `
    <div class="screen">
      <div class="kicker">${escapeHtml(item.title)}</div>
      <div class="stats-grid two-col">
        <div class="stat"><span>Down</span><strong>${escapeHtml(live.down_speed)} MB/s</strong></div>
        <div class="stat"><span>Up</span><strong>${escapeHtml(live.up_speed)} MB/s</strong></div>
        <div class="stat"><span>Active</span><strong>${escapeHtml(live.active_count)}</strong></div>
        <div class="stat"><span>Queueing</span><strong>${live.queueing ? 'On' : 'Off'}</strong></div>
      </div>
      <div class="list-block compact">${(live.top || []).map(t => `<div class="list-row"><div class="list-title">${escapeHtml(t.name)}</div><div class="list-sub">${escapeHtml(t.progress)}% · ${escapeHtml(t.state)} · ${escapeHtml(t.dlspeed)} MB/s</div></div>`).join('')}</div>
    </div>`;
}

function renderJellyfin(item) {
  const live = item.config.live || {};
  if (!live.ok) {
    root.innerHTML = `<div class="screen"><div class="kicker">${escapeHtml(item.title)}</div><div class="big-title">Jellyfin unavailable</div><div class="big-subtext">${escapeHtml(live.message || 'Configure Jellyfin in Settings.')}</div></div>`;
    return;
  }
  root.innerHTML = `
    <div class="screen">
      <div class="kicker">${escapeHtml(item.title)}</div>
      <div class="section-label">Now Playing</div>
      <div class="list-block compact">${(live.playing || []).length ? (live.playing || []).map(p => `<div class="list-row"><div class="list-title">${escapeHtml(p.title)}</div><div class="list-sub">${escapeHtml(p.user)} · ${escapeHtml(p.type)} · ${escapeHtml(p.progress)}%</div></div>`).join('') : '<div class="big-subtext">Nothing is playing right now.</div>'}</div>
      <div class="section-label">Recently Added</div>
      <div class="list-block compact">${(live.latest || []).map(m => `<div class="list-row"><div class="list-title">${escapeHtml(m.name)}</div><div class="list-sub">${escapeHtml(m.type)} ${m.year ? '· ' + escapeHtml(m.year) : ''}</div></div>`).join('')}</div>
    </div>`;
}

function renderJellyseerr(item) {
  const live = item.config.live || {};
  if (!live.ok) {
    root.innerHTML = `<div class="screen"><div class="kicker">${escapeHtml(item.title)}</div><div class="big-title">Jellyseerr unavailable</div><div class="big-subtext">${escapeHtml(live.message || 'Configure Jellyseerr in Settings.')}</div></div>`;
    return;
  }
  root.innerHTML = `
    <div class="screen">
      <div class="kicker">${escapeHtml(item.title)}</div>
      <div class="stats-grid one-col"><div class="stat"><span>Pending</span><strong>${escapeHtml(live.pending)}</strong></div></div>
      <div class="list-block compact">${(live.requests || []).map(r => `<div class="list-row"><div class="list-title">${escapeHtml(r.title)}</div><div class="list-sub">${escapeHtml(r.type)} · Requested by ${escapeHtml(r.requested_by)} · Status ${escapeHtml(r.status)}</div></div>`).join('')}</div>
    </div>`;
}

function renderSpotify(item) {
  const live = item.config.live || {};
  if (!live.ok) {
    root.innerHTML = `<div class="screen"><div class="kicker">${escapeHtml(item.title)}</div><div class="big-title">Spotify unavailable</div><div class="big-subtext">${escapeHtml(live.message || 'Configure Spotify in Settings.')}</div></div>`;
    return;
  }
  const pct = Math.max(0, Math.min(100, Math.round((live.progress_ms || 0) / Math.max((live.duration_ms || 1), 1) * 100)));
  root.innerHTML = `
    <div class="screen">
      <div class="kicker">${escapeHtml(item.title)}</div>
      <div class="big-title">${escapeHtml(live.title)}</div>
      <div class="big-subtext">${escapeHtml(live.artist)}</div>
      <div class="big-subtext">${escapeHtml(live.album)}</div>
      <div class="progress-bar"><div class="progress-fill" style="width:${pct}%"></div></div>
      <div class="footer-note">${live.playing ? 'Playing' : 'Paused'}</div>
    </div>`;
}

function renderSirius(item) {
  const live = item.config.live || {};
  if (!live.ok) {
    root.innerHTML = `<div class="screen"><div class="kicker">${escapeHtml(item.title)}</div><div class="big-title">SiriusXM placeholder</div><div class="big-subtext">${escapeHtml(live.message || 'Add manual values in Settings.')}</div></div>`;
    return;
  }
  root.innerHTML = `
    <div class="screen">
      <div class="kicker">${escapeHtml(item.title)}</div>
      <div class="big-title">${escapeHtml(live.channel || 'SiriusXM')}</div>
      <div class="big-body">${escapeHtml(live.now_playing || 'No now-playing text yet.')}</div>
    </div>`;
}

let cleanupFn = null;
async function renderCurrent() {
  if (!payload || !payload.items || !payload.items.length) {
    root.innerHTML = `<div class="screen"><div class="big-title">No playlist items assigned</div></div>`;
    return;
  }
  if (cleanupFn) { cleanupFn(); cleanupFn = null; }
  const item = payload.items[currentIndex];
  switch (item.module_type) {
    case 'clock': cleanupFn = renderClock(item); break;
    case 'openweather': renderOpenWeather(item); break;
    case 'calendar': renderCalendar(item); break;
    case 'custom_text': renderCustomText(item); break;
    case 'quote': renderQuote(item); break;
    case 'photos': renderPhotos(item, false); break;
    case 'nas_photos': renderPhotos(item, true); break;
    case 'qbittorrent': renderQbit(item); break;
    case 'jellyfin': renderJellyfin(item); break;
    case 'jellyseerr': renderJellyseerr(item); break;
    case 'spotify': renderSpotify(item); break;
    case 'siriusxm': renderSirius(item); break;
    default:
      root.innerHTML = `<div class="screen"><div class="big-title">Unsupported module: ${escapeHtml(item.module_type)}</div></div>`;
  }
  clearTimeout(timer);
  timer = setTimeout(nextScreen, Math.max(5, item.duration_seconds) * 1000);
}

async function nextScreen() {
  if (!payload || !payload.items || payload.items.length === 0) return;
  currentIndex = (currentIndex + 1) % payload.items.length;
  if (currentIndex === 0) {
    try { await fetchPayload(); } catch (err) { console.error(err); }
  }
  await renderCurrent();
}

async function boot() {
  try {
    await fetchPayload();
    await renderCurrent();
  } catch (err) {
    root.innerHTML = `<div class="screen"><div class="big-title">Unable to load device</div><div class="big-subtext">${escapeHtml(err.message)}</div></div>`;
  }
}

boot();
document.addEventListener('click', nextScreen);
