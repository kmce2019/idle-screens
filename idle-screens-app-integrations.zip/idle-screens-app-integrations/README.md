# Idle Screens

Idle Screens is a self-hosted dashboard rotator for old Android tablets and spare screens.

## New in this build
- Settings page for qBittorrent, Jellyfin, Jellyseerr, OpenWeather, NAS Photos, Calendar, Spotify, and SiriusXM placeholder values
- New playlist modules for those services
- Local photo uploads still supported
- No Docker required

## Quick start on Ubuntu / Debian / Mint

```bash
sudo apt update
sudo apt install python3 python3-pip python3-venv -y
cd ~/idle-screens-app-integrations
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open:
- Admin: `http://YOUR-IP:8008/`
- Settings: `http://YOUR-IP:8008/settings`
- Sample device: `http://YOUR-IP:8008/device/kitchen-tablet`

## Notes on integrations

### qBittorrent
Use the full base URL, for example:
- `http://192.168.1.50:8080`

### Jellyfin
Needs:
- base URL
- API key
- optional user ID for Recently Added

### Jellyseerr
Needs:
- base URL
- API key

### OpenWeather
Needs:
- API key
- location like `Lufkin,TX,US`

### NAS Photos
This build supports either:
- a JSON feed of image URLs
- an RSS/media feed of image URLs
- or it falls back to local uploaded photos

### Calendar
This build expects an ICS / iCal URL.
If your calendar requires authentication, add username and app password.

### Spotify
The most reliable option is to provide a valid **access token**.
Optional refresh support is included if you also provide:
- refresh token
- client ID
- client secret

### SiriusXM
There is no simple public now-playing API in this build.
This module is currently a manual placeholder driven by Settings.

## Production later
Once you're happy with the app, the next step is to run it with:
- Gunicorn
- systemd
- optional Nginx reverse proxy

