#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source .venv/bin/activate
export $(grep -v '^#' .env 2>/dev/null | xargs -r)
exec gunicorn --workers 2 --bind 0.0.0.0:8008 wsgi:application
