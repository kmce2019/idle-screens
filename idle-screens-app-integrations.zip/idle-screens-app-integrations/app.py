from __future__ import annotations

import json
import os
import random
import sqlite3
import uuid
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any
from urllib.parse import urljoin
import xml.etree.ElementTree as ET

import requests
from flask import (
    Flask,
    flash,
    g,
    jsonify,
    redirect,
    render_template,
    request,
    send_from_directory,
    url_for,
)
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "idle_screens.db"
UPLOAD_DIR = BASE_DIR / "static" / "uploads"
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}
HTTP_TIMEOUT = 12

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("IDLE_SCREENS_SECRET", "idle-screens-dev-secret")
app.config["UPLOAD_FOLDER"] = str(UPLOAD_DIR)
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024


# ---------- Database helpers ----------
def get_db() -> sqlite3.Connection:
    if "db" not in g:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        g.db = conn
    return g.db


@app.teardown_appcontext
def close_db(_: Any) -> None:
    db = g.pop("db", None)
    if db is not None:
        db.close()


def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def json_loads_safe(value: str | None, default: Any) -> Any:
    if not value:
        return default
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return default


def slugify(value: str) -> str:
    safe = "".join(ch.lower() if ch.isalnum() else "-" for ch in value)
    while "--" in safe:
        safe = safe.replace("--", "-")
    return safe.strip("-") or f"device-{uuid.uuid4().hex[:6]}"


def safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def dt_display(value: str | None) -> str:
    if not value:
        return "—"
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt.astimezone().strftime("%Y-%m-%d %I:%M %p")
    except ValueError:
        return value


app.jinja_env.filters["dt_display"] = dt_display


# ---------- Initialization ----------
def init_db() -> None:
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH)
    cursor = db.cursor()

    cursor.executescript(
        """
        CREATE TABLE IF NOT EXISTS devices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            slug TEXT NOT NULL UNIQUE,
            location TEXT,
            playlist_id INTEGER,
            is_active INTEGER NOT NULL DEFAULT 1,
            last_seen TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (playlist_id) REFERENCES playlists(id)
        );

        CREATE TABLE IF NOT EXISTS playlists (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS playlist_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            playlist_id INTEGER NOT NULL,
            module_type TEXT NOT NULL,
            title TEXT NOT NULL,
            duration_seconds INTEGER NOT NULL DEFAULT 20,
            sort_order INTEGER NOT NULL DEFAULT 0,
            config_json TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (playlist_id) REFERENCES playlists(id)
        );

        CREATE TABLE IF NOT EXISTS photos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            filename TEXT NOT NULL,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS app_settings (
            key TEXT PRIMARY KEY,
            value TEXT,
            updated_at TEXT NOT NULL
        );
        """
    )

    db.commit()

    playlist_count = cursor.execute("SELECT COUNT(*) FROM playlists").fetchone()[0]
    if playlist_count == 0:
        created = now_iso()
        cursor.execute(
            "INSERT INTO playlists (name, created_at, updated_at) VALUES (?, ?, ?)",
            ("Home Default", created, created),
        )
        playlist_id = cursor.lastrowid

        seed_items = [
            (
                playlist_id,
                "clock",
                "Clock",
                20,
                1,
                json.dumps({"show_seconds": False, "show_date": True, "timezone": "America/Chicago"}),
                created,
                created,
            ),
            (
                playlist_id,
                "openweather",
                "Lufkin Weather",
                30,
                2,
                json.dumps({"label": "Lufkin, TX"}),
                created,
                created,
            ),
            (
                playlist_id,
                "custom_text",
                "Message",
                25,
                3,
                json.dumps({"body": "Welcome to Idle Screens.", "subtext": "Edit this in the admin panel."}),
                created,
                created,
            ),
        ]
        cursor.executemany(
            """
            INSERT INTO playlist_items (
                playlist_id, module_type, title, duration_seconds, sort_order,
                config_json, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            seed_items,
        )

        cursor.execute(
            """
            INSERT INTO devices (name, slug, location, playlist_id, is_active, last_seen, created_at, updated_at)
            VALUES (?, ?, ?, ?, 1, ?, ?, ?)
            """,
            (
                "Kitchen Tablet",
                "kitchen-tablet",
                "Kitchen",
                playlist_id,
                created,
                created,
                created,
            ),
        )

    default_settings = {
        "openweather_base_url": "https://api.openweathermap.org/data/2.5/weather",
        "openweather_location": "Lufkin,TX,US",
        "spotify_base_url": "https://api.spotify.com/v1/me/player/currently-playing",
        "calendar_max_items": "5",
        "jellyfin_base_url": "",
        "jellyfin_api_key": "",
        "jellyfin_user_id": "",
        "jellyseerr_base_url": "",
        "jellyseerr_api_key": "",
        "qbittorrent_base_url": "",
        "qbittorrent_username": "",
        "qbittorrent_password": "",
        "nas_photos_url": "",
        "nas_photos_username": "",
        "nas_photos_password": "",
        "calendar_url": "",
        "calendar_username": "",
        "calendar_password": "",
        "spotify_access_token": "",
        "spotify_refresh_token": "",
        "spotify_client_id": "",
        "spotify_client_secret": "",
        "siriusxm_now_playing": "",
        "siriusxm_channel": "",
    }

    for key, value in default_settings.items():
        cursor.execute(
            "INSERT OR IGNORE INTO app_settings (key, value, updated_at) VALUES (?, ?, ?)",
            (key, value, now_iso()),
        )

    db.commit()
    db.close()


# ---------- Queries ----------
def fetch_all(query: str, params: tuple = ()) -> list[sqlite3.Row]:
    return get_db().execute(query, params).fetchall()


def fetch_one(query: str, params: tuple = ()) -> sqlite3.Row | None:
    return get_db().execute(query, params).fetchone()


def execute(query: str, params: tuple = ()) -> int:
    db = get_db()
    cur = db.execute(query, params)
    db.commit()
    return cur.lastrowid


def get_settings() -> dict[str, str]:
    rows = fetch_all("SELECT key, value FROM app_settings ORDER BY key")
    return {row["key"]: row["value"] or "" for row in rows}


def set_setting(key: str, value: str) -> None:
    execute(
        """
        INSERT INTO app_settings (key, value, updated_at)
        VALUES (?, ?, ?)
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
        """,
        (key, value, now_iso()),
    )


# ---------- Service helpers ----------
def fetch_json(url: str, *, method: str = "GET", headers: dict[str, str] | None = None, auth: tuple[str, str] | None = None,
               params: dict[str, Any] | None = None, data: dict[str, Any] | None = None, json_data: dict[str, Any] | None = None,
               cookies: dict[str, str] | None = None) -> Any:
    response = requests.request(
        method,
        url,
        headers=headers,
        auth=auth,
        params=params,
        data=data,
        json=json_data,
        cookies=cookies,
        timeout=HTTP_TIMEOUT,
    )
    response.raise_for_status()
    return response.json()


def service_openweather(settings: dict[str, str], item_config: dict[str, Any]) -> dict[str, Any]:
    api_key = settings.get("openweather_api_key", "").strip()
    location = item_config.get("location") or settings.get("openweather_location", "").strip()
    if not api_key or not location:
        return {"ok": False, "message": "OpenWeather API key or location not configured."}
    data = fetch_json(
        settings.get("openweather_base_url") or "https://api.openweathermap.org/data/2.5/weather",
        params={"appid": api_key, "q": location, "units": "imperial"},
    )
    weather = (data.get("weather") or [{}])[0]
    main = data.get("main") or {}
    wind = data.get("wind") or {}
    return {
        "ok": True,
        "label": item_config.get("label") or data.get("name") or location,
        "temp": round(main.get("temp", 0)),
        "feels_like": round(main.get("feels_like", 0)),
        "humidity": safe_int(main.get("humidity")),
        "wind": round(safe_float(wind.get("speed"))),
        "summary": weather.get("description", "Current conditions").title(),
        "icon": weather.get("icon", ""),
    }


def service_qbittorrent(settings: dict[str, str], item_config: dict[str, Any]) -> dict[str, Any]:
    base = settings.get("qbittorrent_base_url", "").rstrip("/")
    user = settings.get("qbittorrent_username", "")
    pwd = settings.get("qbittorrent_password", "")
    if not base or not user or not pwd:
        return {"ok": False, "message": "qBittorrent server or credentials not configured."}
    session = requests.Session()
    login = session.post(f"{base}/api/v2/auth/login", data={"username": user, "password": pwd}, timeout=HTTP_TIMEOUT)
    login.raise_for_status()
    if login.text.strip() != "Ok.":
        raise RuntimeError("qBittorrent login failed.")
    info = session.get(f"{base}/api/v2/transfer/info", timeout=HTTP_TIMEOUT).json()
    torrents = session.get(f"{base}/api/v2/torrents/info", params={"limit": item_config.get("limit", 5)}, timeout=HTTP_TIMEOUT).json()
    top = []
    for torrent in torrents[: item_config.get("limit", 5)]:
        top.append({
            "name": torrent.get("name", "Untitled"),
            "progress": round((torrent.get("progress") or 0) * 100),
            "state": (torrent.get("state") or "").replace("_", " ").title(),
            "dlspeed": round((torrent.get("dlspeed") or 0) / 1024 / 1024, 1),
        })
    return {
        "ok": True,
        "down_speed": round((info.get("dl_info_speed") or 0) / 1024 / 1024, 1),
        "up_speed": round((info.get("up_info_speed") or 0) / 1024 / 1024, 1),
        "queueing": bool(info.get("queueing")),
        "active_count": len([t for t in torrents if (t.get("state") or "").startswith("down") or (t.get("state") or "").startswith("up")]),
        "top": top,
    }


def service_jellyfin(settings: dict[str, str], item_config: dict[str, Any]) -> dict[str, Any]:
    base = settings.get("jellyfin_base_url", "").rstrip("/")
    api_key = settings.get("jellyfin_api_key", "")
    user_id = settings.get("jellyfin_user_id", "")
    if not base or not api_key:
        return {"ok": False, "message": "Jellyfin base URL or API key not configured."}
    headers = {"X-Emby-Token": api_key}
    sessions = fetch_json(f"{base}/Sessions", headers=headers)
    playing = []
    for session in sessions:
        now_playing = session.get("NowPlayingItem") or {}
        if now_playing:
            playing.append({
                "user": session.get("UserName") or "Unknown",
                "title": now_playing.get("Name") or "Unknown Title",
                "type": now_playing.get("Type") or "Item",
                "progress": round(((session.get("PlayState") or {}).get("PositionTicks") or 0) / max((now_playing.get("RunTimeTicks") or 1), 1) * 100),
            })
    latest = []
    if user_id:
        latest_items = fetch_json(f"{base}/Users/{user_id}/Items/Latest", headers=headers)
        for media in latest_items[: item_config.get("limit", 6)]:
            latest.append({
                "name": media.get("Name", "Untitled"),
                "type": media.get("Type", "Item"),
                "year": media.get("ProductionYear") or "",
            })
    return {"ok": True, "playing": playing, "latest": latest}


def service_jellyseerr(settings: dict[str, str], item_config: dict[str, Any]) -> dict[str, Any]:
    base = settings.get("jellyseerr_base_url", "").rstrip("/")
    api_key = settings.get("jellyseerr_api_key", "")
    if not base or not api_key:
        return {"ok": False, "message": "Jellyseerr base URL or API key not configured."}
    data = fetch_json(f"{base}/api/v1/request", headers={"X-Api-Key": api_key}, params={"take": item_config.get("limit", 5), "skip": 0, "sort": "added"})
    results = []
    for req in (data.get("results") or [])[: item_config.get("limit", 5)]:
        media = req.get("media") or {}
        results.append({
            "title": media.get("title") or media.get("name") or "Untitled",
            "status": (req.get("status") or 1),
            "requested_by": ((req.get("requestedBy") or {}).get("displayName") or (req.get("requestedBy") or {}).get("username") or "Unknown"),
            "type": media.get("mediaType") or "media",
        })
    pending = len([r for r in results if r["status"] in [1, 2]] )
    return {"ok": True, "requests": results, "pending": pending}


def service_nas_photos(settings: dict[str, str], item_config: dict[str, Any]) -> dict[str, Any]:
    url = settings.get("nas_photos_url", "").strip()
    if url:
        photos = []
        if url.lower().endswith(".json"):
            data = fetch_json(url)
            for entry in data[: item_config.get("limit", 10)]:
                if isinstance(entry, dict) and entry.get("url"):
                    photos.append({"title": entry.get("title", "Photo"), "url": entry["url"]})
        elif url.lower().endswith(".xml") or "rss" in url.lower():
            resp = requests.get(url, timeout=HTTP_TIMEOUT)
            resp.raise_for_status()
            root = ET.fromstring(resp.text)
            ns_title = '{http://search.yahoo.com/mrss/}content'
            for item in root.findall('.//item')[: item_config.get("limit", 10)]:
                media = item.find(ns_title)
                if media is not None and media.attrib.get('url'):
                    photos.append({"title": item.findtext('title', default='Photo'), "url": media.attrib['url']})
        if photos:
            return {"ok": True, "photos": photos}
    local_photos = fetch_all("SELECT * FROM photos ORDER BY created_at DESC")
    if local_photos:
        photos = [
            {"title": p["title"], "url": url_for("uploaded_file", filename=p["filename"])}
            for p in local_photos[: item_config.get("limit", 12)]
        ]
        if item_config.get("shuffle", True):
            random.shuffle(photos)
        return {"ok": True, "photos": photos}
    return {"ok": False, "message": "No NAS photo feed configured and no local photos uploaded."}


def parse_ics_events(text: str, max_items: int = 5) -> list[dict[str, str]]:
    events: list[dict[str, str]] = []
    current: dict[str, str] = {}
    in_event = False
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if line == "BEGIN:VEVENT":
            in_event = True
            current = {}
            continue
        if line == "END:VEVENT":
            in_event = False
            if current:
                events.append(current)
            current = {}
            continue
        if not in_event or ":" not in line:
            continue
        key, value = line.split(":", 1)
        current[key] = value
    now = datetime.now(timezone.utc)
    normalized = []
    for event in events:
        start_raw = event.get("DTSTART") or next((v for k, v in event.items() if k.startswith("DTSTART;")), None)
        if not start_raw:
            continue
        try:
            if len(start_raw) == 8:
                start = datetime.strptime(start_raw, "%Y%m%d").replace(tzinfo=timezone.utc)
            elif start_raw.endswith("Z"):
                start = datetime.strptime(start_raw, "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc)
            else:
                start = datetime.strptime(start_raw[:15], "%Y%m%dT%H%M%S").astimezone()
                if start.tzinfo is None:
                    start = start.replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        if start < now - timedelta(hours=12):
            continue
        normalized.append({
            "summary": event.get("SUMMARY", "Untitled Event"),
            "location": event.get("LOCATION", ""),
            "start": start,
        })
    normalized.sort(key=lambda x: x["start"])
    output = []
    for event in normalized[:max_items]:
        output.append({
            "summary": event["summary"],
            "location": event["location"],
            "start": event["start"].astimezone().strftime("%a %b %d · %I:%M %p"),
        })
    return output


def service_calendar(settings: dict[str, str], item_config: dict[str, Any]) -> dict[str, Any]:
    url = settings.get("calendar_url", "").strip()
    user = settings.get("calendar_username", "").strip()
    pwd = settings.get("calendar_password", "").strip()
    if not url:
        return {"ok": False, "message": "Calendar URL not configured."}
    response = requests.get(url, auth=(user, pwd) if user or pwd else None, timeout=HTTP_TIMEOUT)
    response.raise_for_status()
    items = parse_ics_events(response.text, max_items=safe_int(item_config.get("limit"), safe_int(settings.get("calendar_max_items"), 5)))
    return {"ok": True, "events": items}


def refresh_spotify_access_token(settings: dict[str, str]) -> str:
    refresh_token = settings.get("spotify_refresh_token", "").strip()
    client_id = settings.get("spotify_client_id", "").strip()
    client_secret = settings.get("spotify_client_secret", "").strip()
    if not refresh_token or not client_id or not client_secret:
        return settings.get("spotify_access_token", "").strip()
    response = requests.post(
        "https://accounts.spotify.com/api/token",
        data={"grant_type": "refresh_token", "refresh_token": refresh_token},
        auth=(client_id, client_secret),
        timeout=HTTP_TIMEOUT,
    )
    response.raise_for_status()
    data = response.json()
    token = data.get("access_token", "").strip()
    if token:
        set_setting("spotify_access_token", token)
    return token


def service_spotify(settings: dict[str, str], item_config: dict[str, Any]) -> dict[str, Any]:
    token = settings.get("spotify_access_token", "").strip() or refresh_spotify_access_token(settings)
    if not token:
        return {"ok": False, "message": "Spotify access token not configured."}
    response = requests.get(
        settings.get("spotify_base_url") or "https://api.spotify.com/v1/me/player/currently-playing",
        headers={"Authorization": f"Bearer {token}"},
        timeout=HTTP_TIMEOUT,
    )
    if response.status_code == 204:
        return {"ok": False, "message": "Nothing is currently playing on Spotify."}
    response.raise_for_status()
    data = response.json()
    item = data.get("item") or {}
    artists = ", ".join(a.get("name", "") for a in item.get("artists") or [])
    return {
        "ok": True,
        "title": item.get("name", "Unknown Track"),
        "artist": artists,
        "album": (item.get("album") or {}).get("name", ""),
        "playing": data.get("is_playing", False),
        "progress_ms": data.get("progress_ms", 0),
        "duration_ms": item.get("duration_ms", 1),
    }


def service_siriusxm(settings: dict[str, str], item_config: dict[str, Any]) -> dict[str, Any]:
    now_playing = settings.get("siriusxm_now_playing", "").strip()
    channel = settings.get("siriusxm_channel", "").strip()
    if not now_playing and not channel:
        return {"ok": False, "message": "SiriusXM does not expose a simple public now-playing API. Use this as a manual placeholder for now."}
    return {"ok": True, "channel": channel, "now_playing": now_playing}


def enrich_item(module_type: str, settings: dict[str, str], item_config: dict[str, Any]) -> dict[str, Any]:
    if module_type == "openweather":
        return service_openweather(settings, item_config)
    if module_type == "qbittorrent":
        return service_qbittorrent(settings, item_config)
    if module_type == "jellyfin":
        return service_jellyfin(settings, item_config)
    if module_type == "jellyseerr":
        return service_jellyseerr(settings, item_config)
    if module_type == "nas_photos":
        return service_nas_photos(settings, item_config)
    if module_type == "calendar":
        return service_calendar(settings, item_config)
    if module_type == "spotify":
        return service_spotify(settings, item_config)
    if module_type == "siriusxm":
        return service_siriusxm(settings, item_config)
    return {}


# ---------- Routes ----------
@app.route("/")
def index() -> str:
    devices = fetch_all(
        """
        SELECT d.*, p.name AS playlist_name
        FROM devices d
        LEFT JOIN playlists p ON p.id = d.playlist_id
        ORDER BY d.name
        """
    )
    playlists = fetch_all("SELECT * FROM playlists ORDER BY name")
    photos = fetch_all("SELECT * FROM photos ORDER BY created_at DESC")
    return render_template("index.html", devices=devices, playlists=playlists, photos=photos)


@app.route("/settings", methods=["GET", "POST"])
def settings_page() -> str | Any:
    if request.method == "POST":
        fields = [
            "qbittorrent_base_url", "qbittorrent_username", "qbittorrent_password",
            "jellyfin_base_url", "jellyfin_api_key", "jellyfin_user_id",
            "jellyseerr_base_url", "jellyseerr_api_key",
            "openweather_api_key", "openweather_location", "openweather_base_url",
            "nas_photos_url", "nas_photos_username", "nas_photos_password",
            "calendar_url", "calendar_username", "calendar_password", "calendar_max_items",
            "spotify_access_token", "spotify_refresh_token", "spotify_client_id", "spotify_client_secret", "spotify_base_url",
            "siriusxm_channel", "siriusxm_now_playing",
        ]
        for field in fields:
            set_setting(field, request.form.get(field, "").strip())
        flash("Settings saved.", "success")
        return redirect(url_for("settings_page"))
    settings = get_settings()
    return render_template("settings.html", settings=settings)


@app.route("/devices/new", methods=["POST"])
def create_device() -> Any:
    name = request.form.get("name", "").strip()
    location = request.form.get("location", "").strip()
    playlist_id = request.form.get("playlist_id", type=int)
    if not name:
        flash("Device name is required.", "error")
        return redirect(url_for("index"))

    created = now_iso()
    slug = slugify(request.form.get("slug", "").strip() or name)
    try:
        execute(
            """
            INSERT INTO devices (name, slug, location, playlist_id, is_active, last_seen, created_at, updated_at)
            VALUES (?, ?, ?, ?, 1, ?, ?, ?)
            """,
            (name, slug, location or None, playlist_id, created, created, created),
        )
        flash("Device created.", "success")
    except sqlite3.IntegrityError:
        flash("That device slug already exists.", "error")
    return redirect(url_for("index"))


@app.route("/devices/<int:device_id>/delete", methods=["POST"])
def delete_device(device_id: int) -> Any:
    execute("DELETE FROM devices WHERE id = ?", (device_id,))
    flash("Device deleted.", "success")
    return redirect(url_for("index"))


@app.route("/playlists/new", methods=["POST"])
def create_playlist() -> Any:
    name = request.form.get("name", "").strip()
    if not name:
        flash("Playlist name is required.", "error")
        return redirect(url_for("index"))
    created = now_iso()
    execute(
        "INSERT INTO playlists (name, created_at, updated_at) VALUES (?, ?, ?)",
        (name, created, created),
    )
    flash("Playlist created.", "success")
    return redirect(url_for("index"))


@app.route("/playlists/<int:playlist_id>")
def playlist_detail(playlist_id: int) -> str:
    playlist = fetch_one("SELECT * FROM playlists WHERE id = ?", (playlist_id,))
    if not playlist:
        return render_template("not_found.html", message="Playlist not found."), 404
    items = fetch_all(
        "SELECT * FROM playlist_items WHERE playlist_id = ? ORDER BY sort_order, id",
        (playlist_id,),
    )
    photos = fetch_all("SELECT * FROM photos ORDER BY created_at DESC")
    return render_template("playlist_detail.html", playlist=playlist, items=items, photos=photos)


@app.route("/playlists/<int:playlist_id>/items/new", methods=["POST"])
def create_playlist_item(playlist_id: int) -> Any:
    module_type = request.form.get("module_type", "clock").strip()
    title = request.form.get("title", "").strip() or module_type.replace("_", " ").title()
    duration_seconds = request.form.get("duration_seconds", type=int) or 20
    sort_order = request.form.get("sort_order", type=int) or 0

    config: dict[str, Any] = {}
    if module_type == "clock":
        config = {
            "show_seconds": request.form.get("show_seconds") == "on",
            "show_date": request.form.get("show_date") != "off",
            "timezone": request.form.get("timezone", "America/Chicago").strip() or "America/Chicago",
        }
    elif module_type == "custom_text":
        config = {
            "body": request.form.get("body", "").strip(),
            "subtext": request.form.get("subtext", "").strip(),
        }
    elif module_type == "quote":
        quotes_raw = request.form.get("quotes", "").strip()
        quotes = [line.strip() for line in quotes_raw.splitlines() if line.strip()]
        config = {"quotes": quotes or ["Add your own quotes in the admin panel."]}
    elif module_type in {"photos", "nas_photos"}:
        photo_ids = request.form.getlist("photo_ids")
        config = {
            "photo_ids": [int(pid) for pid in photo_ids if pid.isdigit()],
            "shuffle": request.form.get("shuffle") == "on",
            "limit": request.form.get("limit", type=int) or 10,
        }
    elif module_type in {"qbittorrent", "jellyfin", "jellyseerr", "calendar"}:
        config = {"limit": request.form.get("limit", type=int) or 5}
    elif module_type == "openweather":
        config = {
            "label": request.form.get("label", "").strip(),
            "location": request.form.get("location", "").strip(),
        }

    created = now_iso()
    execute(
        """
        INSERT INTO playlist_items (
            playlist_id, module_type, title, duration_seconds, sort_order,
            config_json, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            playlist_id,
            module_type,
            title,
            duration_seconds,
            sort_order,
            json.dumps(config),
            created,
            created,
        ),
    )
    flash("Playlist item added.", "success")
    return redirect(url_for("playlist_detail", playlist_id=playlist_id))


@app.route("/playlists/<int:playlist_id>/items/<int:item_id>/delete", methods=["POST"])
def delete_playlist_item(playlist_id: int, item_id: int) -> Any:
    execute("DELETE FROM playlist_items WHERE id = ?", (item_id,))
    flash("Playlist item deleted.", "success")
    return redirect(url_for("playlist_detail", playlist_id=playlist_id))


@app.route("/photos/upload", methods=["POST"])
def upload_photo() -> Any:
    file = request.files.get("photo")
    title = request.form.get("title", "").strip()
    if not file or file.filename == "":
        flash("Please choose a photo.", "error")
        return redirect(url_for("index"))
    if not allowed_file(file.filename):
        flash("Unsupported file type.", "error")
        return redirect(url_for("index"))

    filename = f"{uuid.uuid4().hex}_{secure_filename(file.filename)}"
    save_path = UPLOAD_DIR / filename
    file.save(save_path)
    execute(
        "INSERT INTO photos (title, filename, created_at) VALUES (?, ?, ?)",
        (title or file.filename, filename, now_iso()),
    )
    flash("Photo uploaded.", "success")
    return redirect(url_for("index"))


@app.route("/photos/<int:photo_id>/delete", methods=["POST"])
def delete_photo(photo_id: int) -> Any:
    photo = fetch_one("SELECT * FROM photos WHERE id = ?", (photo_id,))
    if photo:
        path = UPLOAD_DIR / photo["filename"]
        if path.exists():
            path.unlink()
        execute("DELETE FROM photos WHERE id = ?", (photo_id,))
        flash("Photo deleted.", "success")
    return redirect(url_for("index"))


@app.route("/device/<slug>")
def device_view(slug: str) -> str:
    device = fetch_one(
        """
        SELECT d.*, p.name AS playlist_name
        FROM devices d
        LEFT JOIN playlists p ON p.id = d.playlist_id
        WHERE d.slug = ? AND d.is_active = 1
        """,
        (slug,),
    )
    if not device:
        return render_template("not_found.html", message="Device not found."), 404

    execute(
        "UPDATE devices SET last_seen = ?, updated_at = ? WHERE id = ?",
        (now_iso(), now_iso(), device["id"]),
    )
    return render_template("device_view.html", device=device)


@app.route("/api/device/<slug>")
def device_payload(slug: str) -> Any:
    device = fetch_one(
        "SELECT * FROM devices WHERE slug = ? AND is_active = 1",
        (slug,),
    )
    if not device:
        return jsonify({"error": "Device not found"}), 404

    items = fetch_all(
        "SELECT * FROM playlist_items WHERE playlist_id = ? ORDER BY sort_order, id",
        (device["playlist_id"],),
    )
    settings = get_settings()
    payload_items = []
    for item in items:
        config = json_loads_safe(item["config_json"], {})
        payload: dict[str, Any] = {
            "id": item["id"],
            "module_type": item["module_type"],
            "title": item["title"],
            "duration_seconds": item["duration_seconds"],
            "config": config,
        }
        if item["module_type"] == "quote":
            quotes = config.get("quotes", [])
            payload["config"]["selected_quote"] = random.choice(quotes) if quotes else ""
        if item["module_type"] == "photos":
            photo_ids = config.get("photo_ids", [])
            photos = []
            if photo_ids:
                placeholders = ",".join("?" for _ in photo_ids)
                query = f"SELECT * FROM photos WHERE id IN ({placeholders}) ORDER BY id"
                photos = fetch_all(query, tuple(photo_ids))
            if not photos:
                photos = fetch_all("SELECT * FROM photos ORDER BY created_at DESC")
            photo_payload = [
                {
                    "id": photo["id"],
                    "title": photo["title"],
                    "url": url_for("uploaded_file", filename=photo["filename"]),
                }
                for photo in photos
            ]
            if config.get("shuffle"):
                random.shuffle(photo_payload)
            payload["config"]["photos"] = photo_payload
        elif item["module_type"] in {"openweather", "qbittorrent", "jellyfin", "jellyseerr", "nas_photos", "calendar", "spotify", "siriusxm"}:
            try:
                payload["config"]["live"] = enrich_item(item["module_type"], settings, config)
            except Exception as exc:  # noqa: BLE001
                payload["config"]["live"] = {"ok": False, "message": str(exc)}
        payload_items.append(payload)

    execute(
        "UPDATE devices SET last_seen = ?, updated_at = ? WHERE id = ?",
        (now_iso(), now_iso(), device["id"]),
    )

    return jsonify(
        {
            "device": {
                "name": device["name"],
                "slug": device["slug"],
                "location": device["location"],
            },
            "items": payload_items,
            "generated_at": now_iso(),
        }
    )


@app.route("/uploads/<path:filename>")
def uploaded_file(filename: str) -> Any:
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename)


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=8008, debug=True)
