# Idle Screens

Idle Screens is a lightweight self-hosted web app for turning old Android tablets into rotating dashboard displays.

## Features in this build

- Device URLs like `/device/kitchen-tablet`
- Playlists with rotating modules
- Modules included in this version:
  - Clock
  - Weather (Open-Meteo)
  - Custom text
  - Quote rotation
  - Photo slideshow
- Photo upload library
- SQLite database
- Simple Flask admin UI
- No Docker required

## Quick start on Ubuntu / Debian

### 1) Upload the project to your server

Copy this whole folder to your server, for example:

```bash
scp -r idle-screens-app user@your-server:/opt/
```

### 2) Install system packages

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip nginx
```

### 3) Create a virtual environment

```bash
cd /opt/idle-screens-app
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 4) Test it directly

```bash
python3 app.py
```

Then visit:

- Admin: `http://SERVER-IP:8008/`
- Sample device: `http://SERVER-IP:8008/device/kitchen-tablet`

### 5) Run it with Gunicorn

Install Gunicorn:

```bash
source /opt/idle-screens-app/.venv/bin/activate
pip install gunicorn
```

Test:

```bash
gunicorn --bind 0.0.0.0:8008 wsgi:application
```

## Optional systemd service

Create `/etc/systemd/system/idle-screens.service`

```ini
[Unit]
Description=Idle Screens
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=/opt/idle-screens-app
Environment="PATH=/opt/idle-screens-app/.venv/bin"
ExecStart=/opt/idle-screens-app/.venv/bin/gunicorn --workers 2 --bind 127.0.0.1:8008 wsgi:application
Restart=always

[Install]
WantedBy=multi-user.target
```

Then:

```bash
sudo chown -R www-data:www-data /opt/idle-screens-app
sudo systemctl daemon-reload
sudo systemctl enable --now idle-screens
sudo systemctl status idle-screens
```

## Optional nginx reverse proxy

Create `/etc/nginx/sites-available/idle-screens`

```nginx
server {
    listen 80;
    server_name _;

    client_max_body_size 25M;

    location /static/ {
        alias /opt/idle-screens-app/static/;
        expires 7d;
    }

    location /uploads/ {
        alias /opt/idle-screens-app/static/uploads/;
        expires 7d;
    }

    location / {
        proxy_pass http://127.0.0.1:8008;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Enable it:

```bash
sudo ln -s /etc/nginx/sites-available/idle-screens /etc/nginx/sites-enabled/idle-screens
sudo nginx -t
sudo systemctl reload nginx
```

## Android tablet setup

1. Open the device URL in Chrome.
2. Example: `http://SERVER-IP/device/kitchen-tablet`
3. Add it to the home screen.
4. Keep the tablet plugged in.
5. Enable developer option **Stay awake while charging** if available.
6. Later, you can switch to Fully Kiosk Browser for a more locked-down kiosk mode.

## Notes

- Weather uses the public Open-Meteo API and needs internet access.
- Photos are stored locally in `static/uploads/`.
- Data is stored in `idle_screens.db`.
- For a future version, calendar, homelab, and school-announcement modules can be added easily.


## New: Settings Page

Open `/settings` to store service connection details for:
- qBitTorrent
- Jellyfin
- Jellyseerr
- OpenWeather
- NAS Photos
- Calendar URL + app password
- Spotify / SiriusXM notes

These credentials are stored in the local SQLite database and are ready for future modules to use.

