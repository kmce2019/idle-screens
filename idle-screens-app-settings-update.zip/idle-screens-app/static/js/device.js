const root = document.getElementById('device-app');
const device = window.IDLE_SCREENS_DEVICE;

let payload = null;
let currentIndex = 0;
let timer = null;
let photoIndex = 0;

async function fetchPayload() {
  const res = await fetch(`/api/device/${device.slug}`);
  if (!res.ok) {
    throw new Error('Could not load device payload');
  }
  payload = await res.json();
}

function formatTime(showSeconds = false, timezone = 'America/Chicago') {
  return new Intl.DateTimeFormat([], {
    hour: 'numeric',
    minute: '2-digit',
    second: showSeconds ? '2-digit' : undefined,
    hour12: true,
    timeZone: timezone
  }).format(new Date());
}

function formatDate(timezone = 'America/Chicago') {
  return new Intl.DateTimeFormat([], {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    timeZone: timezone
  }).format(new Date());
}

async function renderWeather(item) {
  const { latitude, longitude, label } = item.config;
  root.innerHTML = `<div class="screen"><div class="kicker">Weather</div><div class="big-title">Loading ${label || ''}</div></div>`;
  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(latitude)}&longitude=${encodeURIComponent(longitude)}&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m&temperature_unit=fahrenheit&wind_speed_unit=mph`;
    const res = await fetch(url);
    const data = await res.json();
    const current = data.current || {};
    root.innerHTML = `
      <div class="screen">
        <div class="kicker">Weather</div>
        <div class="weather-grid">
          <div class="big-title">${escapeHtml(label || 'Weather')}</div>
          <div class="weather-temp">${Math.round(current.temperature_2m ?? 0)}°</div>
          <div class="weather-meta">Feels like ${Math.round(current.apparent_temperature ?? 0)}° · Wind ${Math.round(current.wind_speed_10m ?? 0)} mph</div>
        </div>
        <div class="footer-note">Powered by Open-Meteo</div>
      </div>
    `;
  } catch (err) {
    root.innerHTML = `<div class="screen"><div class="kicker">Weather</div><div class="big-title">Weather unavailable</div><div class="big-subtext">Check internet access on this tablet.</div></div>`;
  }
}

function renderClock(item) {
  const timezone = item.config.timezone || 'America/Chicago';
  const showSeconds = !!item.config.show_seconds;
  root.innerHTML = `
    <div class="screen">
      <div class="kicker">${escapeHtml(item.title)}</div>
      <div class="big-time" id="clock-time"></div>
      <div class="big-date">${item.config.show_date === false ? '' : escapeHtml(formatDate(timezone))}</div>
    </div>
  `;
  const tick = () => {
    const el = document.getElementById('clock-time');
    if (el) el.textContent = formatTime(showSeconds, timezone);
  };
  tick();
  const interval = setInterval(tick, 1000);
  return () => clearInterval(interval);
}

function renderCustomText(item) {
  root.innerHTML = `
    <div class="screen">
      <div class="kicker">${escapeHtml(item.title)}</div>
      <div class="big-body">${escapeHtml(item.config.body || '')}</div>
      ${item.config.subtext ? `<div class="big-subtext">${escapeHtml(item.config.subtext)}</div>` : ''}
    </div>
  `;
}

function renderQuote(item) {
  const quote = item.config.selected_quote || 'No quote configured.';
  root.innerHTML = `
    <div class="screen">
      <div class="kicker">${escapeHtml(item.title)}</div>
      <div class="quote-text">“${escapeHtml(quote)}”</div>
    </div>
  `;
}

function renderPhotos(item) {
  const photos = item.config.photos || [];
  if (!photos.length) {
    root.innerHTML = `<div class="screen"><div class="big-title">No photos uploaded yet</div></div>`;
    return;
  }
  const photo = photos[photoIndex % photos.length];
  photoIndex += 1;
  root.innerHTML = `
    <div class="screen">
      <div class="photo-stage">
        <img src="${photo.url}" alt="${escapeHtml(photo.title || 'Photo')}">
      </div>
      <div class="footer-note">${escapeHtml(photo.title || '')}</div>
    </div>
  `;
}

let cleanupFn = null;
async function renderCurrent() {
  if (!payload || !payload.items || !payload.items.length) {
    root.innerHTML = `<div class="screen"><div class="big-title">No playlist items assigned</div></div>`;
    return;
  }

  if (cleanupFn) {
    cleanupFn();
    cleanupFn = null;
  }

  const item = payload.items[currentIndex];
  switch (item.module_type) {
    case 'clock':
      cleanupFn = renderClock(item);
      break;
    case 'weather':
      await renderWeather(item);
      break;
    case 'custom_text':
      renderCustomText(item);
      break;
    case 'quote':
      renderQuote(item);
      break;
    case 'photos':
      renderPhotos(item);
      break;
    default:
      root.innerHTML = `<div class="screen"><div class="big-title">Unsupported module: ${escapeHtml(item.module_type)}</div></div>`;
  }

  clearTimeout(timer);
  timer = setTimeout(nextScreen, Math.max(5, item.duration_seconds) * 1000);
}

async function nextScreen() {
  if (!payload || !payload.items || payload.items.length === 0) return;
  currentIndex = (currentIndex + 1) % payload.items.length;
  if (currentIndex === 0) {
    try {
      await fetchPayload();
    } catch (err) {
      console.error(err);
    }
  }
  await renderCurrent();
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

async function boot() {
  try {
    await fetchPayload();
    await renderCurrent();
  } catch (err) {
    root.innerHTML = `<div class="screen"><div class="big-title">Unable to load device</div><div class="big-subtext">${escapeHtml(err.message)}</div></div>`;
  }
}

boot();
document.addEventListener('click', nextScreen);
