from __future__ import annotations

import json
import os
import random
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from flask import (
    Flask,
    flash,
    g,
    jsonify,
    redirect,
    render_template,
    request,
    send_from_directory,
    url_for,
)
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "idle_screens.db"
UPLOAD_DIR = BASE_DIR / "static" / "uploads"
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}

SETTINGS_FIELDS: list[dict[str, Any]] = [
    {
        "section": "qBitTorrent",
        "description": "Connection details for qBitTorrent widgets and download stats.",
        "fields": [
            {"key": "qbittorrent_base_url", "label": "Server URL", "placeholder": "http://10.0.0.50:8080"},
            {"key": "qbittorrent_username", "label": "Username", "placeholder": "admin"},
            {"key": "qbittorrent_password", "label": "Password", "type": "password", "placeholder": "App password"},
        ],
    },
    {
        "section": "Jellyfin",
        "description": "For now playing, recently added media, and library tiles.",
        "fields": [
            {"key": "jellyfin_base_url", "label": "Server URL", "placeholder": "http://10.0.0.51:8096"},
            {"key": "jellyfin_api_key", "label": "API Key", "type": "password", "placeholder": "Jellyfin API key"},
            {"key": "jellyfin_username", "label": "Username (optional)", "placeholder": "kevin"},
        ],
    },
    {
        "section": "Jellyseerr",
        "description": "For request counts, pending approvals, and media request summaries.",
        "fields": [
            {"key": "jellyseerr_base_url", "label": "Server URL", "placeholder": "http://10.0.0.52:5055"},
            {"key": "jellyseerr_api_key", "label": "API Key", "type": "password", "placeholder": "Jellyseerr API key"},
        ],
    },
    {
        "section": "OpenWeather",
        "description": "Use your OpenWeather key for weather modules instead of the free public endpoint.",
        "fields": [
            {"key": "openweather_api_key", "label": "API Key", "type": "password", "placeholder": "OpenWeather API key"},
            {"key": "openweather_location_name", "label": "Default Label", "placeholder": "Lufkin, TX"},
            {"key": "openweather_units", "label": "Units", "placeholder": "imperial"},
        ],
    },
    {
        "section": "NAS Photos",
        "description": "Used later for Synology or NAS-based photo feeds.",
        "fields": [
            {"key": "nas_photos_base_url", "label": "Server URL", "placeholder": "http://10.0.0.60:5000"},
            {"key": "nas_photos_username", "label": "Username", "placeholder": "photos-user"},
            {"key": "nas_photos_password", "label": "Password", "type": "password", "placeholder": "Password or token"},
            {"key": "nas_photos_album", "label": "Default Album", "placeholder": "IdleScreens"},
        ],
    },
    {
        "section": "Calendar",
        "description": "For CalDAV/iCal-based agenda and upcoming events widgets.",
        "fields": [
            {"key": "calendar_url", "label": "Calendar URL", "placeholder": "https://calendar.example.com/dav/user/calendar/"},
            {"key": "calendar_username", "label": "Username / Email", "placeholder": "kevin@example.com"},
            {"key": "calendar_app_password", "label": "App Password", "type": "password", "placeholder": "App password"},
        ],
    },
    {
        "section": "Now Playing",
        "description": "Spotify is ready for credentials now. SiriusXM can be stored as notes until direct integration is added.",
        "fields": [
            {"key": "spotify_client_id", "label": "Spotify Client ID", "placeholder": "Spotify client ID"},
            {"key": "spotify_client_secret", "label": "Spotify Client Secret", "type": "password", "placeholder": "Spotify client secret"},
            {"key": "spotify_refresh_token", "label": "Spotify Refresh Token", "type": "password", "placeholder": "Spotify refresh token"},
            {"key": "siriusxm_notes", "label": "SiriusXM Notes", "type": "textarea", "placeholder": "Account notes, URL, or future integration details"},
        ],
    },
]

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("IDLE_SCREENS_SECRET", "idle-screens-dev-secret")
app.config["UPLOAD_FOLDER"] = str(UPLOAD_DIR)
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024


# ---------- Database helpers ----------
def get_db() -> sqlite3.Connection:
    if "db" not in g:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        g.db = conn
    return g.db


@app.teardown_appcontext
def close_db(_: Any) -> None:
    db = g.pop("db", None)
    if db is not None:
        db.close()


def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def json_loads_safe(value: str | None, default: Any) -> Any:
    if not value:
        return default
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return default


def slugify(value: str) -> str:
    safe = "".join(ch.lower() if ch.isalnum() else "-" for ch in value)
    while "--" in safe:
        safe = safe.replace("--", "-")
    return safe.strip("-") or f"device-{uuid.uuid4().hex[:6]}"


def get_setting(key: str, default: str = "") -> str:
    row = fetch_one("SELECT value FROM settings WHERE key = ?", (key,))
    return row["value"] if row else default


def get_all_settings() -> dict[str, str]:
    rows = fetch_all("SELECT key, value FROM settings ORDER BY key")
    return {row["key"]: row["value"] for row in rows}


def set_setting(key: str, value: str) -> None:
    db = get_db()
    db.execute(
        """
        INSERT INTO settings (key, value, updated_at)
        VALUES (?, ?, ?)
        ON CONFLICT(key) DO UPDATE SET
            value = excluded.value,
            updated_at = excluded.updated_at
        """,
        (key, value, now_iso()),
    )
    db.commit()


# ---------- Initialization ----------
def init_db() -> None:
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH)
    cursor = db.cursor()

    cursor.executescript(
        """
        CREATE TABLE IF NOT EXISTS devices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            slug TEXT NOT NULL UNIQUE,
            location TEXT,
            playlist_id INTEGER,
            is_active INTEGER NOT NULL DEFAULT 1,
            last_seen TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (playlist_id) REFERENCES playlists(id)
        );

        CREATE TABLE IF NOT EXISTS playlists (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS playlist_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            playlist_id INTEGER NOT NULL,
            module_type TEXT NOT NULL,
            title TEXT NOT NULL,
            duration_seconds INTEGER NOT NULL DEFAULT 20,
            sort_order INTEGER NOT NULL DEFAULT 0,
            config_json TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (playlist_id) REFERENCES playlists(id)
        );

        CREATE TABLE IF NOT EXISTS photos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            filename TEXT NOT NULL,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT,
            updated_at TEXT NOT NULL
        );
        """
    )

    db.commit()

    playlist_count = cursor.execute("SELECT COUNT(*) FROM playlists").fetchone()[0]
    if playlist_count == 0:
        created = now_iso()
        cursor.execute(
            "INSERT INTO playlists (name, created_at, updated_at) VALUES (?, ?, ?)",
            ("Home Default", created, created),
        )
        playlist_id = cursor.lastrowid

        seed_items = [
            (
                playlist_id,
                "clock",
                "Clock",
                20,
                1,
                json.dumps({"show_seconds": False, "show_date": True, "timezone": "America/Chicago"}),
                created,
                created,
            ),
            (
                playlist_id,
                "weather",
                "Lufkin Weather",
                30,
                2,
                json.dumps({"latitude": 31.3382, "longitude": -94.7291, "label": "Lufkin, TX"}),
                created,
                created,
            ),
            (
                playlist_id,
                "quote",
                "Daily Quote",
                20,
                3,
                json.dumps(
                    {
                        "quotes": [
                            "Small systems beat big intentions.",
                            "Build once. Use daily.",
                            "Old tablets deserve a second life.",
                        ]
                    }
                ),
                created,
                created,
            ),
            (
                playlist_id,
                "custom_text",
                "Message",
                25,
                4,
                json.dumps({"body": "Welcome to Idle Screens.", "subtext": "Edit this in the admin panel."}),
                created,
                created,
            ),
        ]
        cursor.executemany(
            """
            INSERT INTO playlist_items (
                playlist_id, module_type, title, duration_seconds, sort_order,
                config_json, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            seed_items,
        )

        cursor.execute(
            """
            INSERT INTO devices (name, slug, location, playlist_id, is_active, last_seen, created_at, updated_at)
            VALUES (?, ?, ?, ?, 1, ?, ?, ?)
            """,
            (
                "Kitchen Tablet",
                "kitchen-tablet",
                "Kitchen",
                playlist_id,
                created,
                created,
                created,
            ),
        )

    db.commit()
    db.close()


# ---------- Queries ----------
def fetch_all(query: str, params: tuple = ()) -> list[sqlite3.Row]:
    return get_db().execute(query, params).fetchall()


def fetch_one(query: str, params: tuple = ()) -> sqlite3.Row | None:
    return get_db().execute(query, params).fetchone()


def execute(query: str, params: tuple = ()) -> int:
    db = get_db()
    cur = db.execute(query, params)
    db.commit()
    return cur.lastrowid


# ---------- Routes ----------
@app.route("/")
def index() -> str:
    devices = fetch_all(
        """
        SELECT d.*, p.name AS playlist_name
        FROM devices d
        LEFT JOIN playlists p ON p.id = d.playlist_id
        ORDER BY d.name
        """
    )
    playlists = fetch_all("SELECT * FROM playlists ORDER BY name")
    photos = fetch_all("SELECT * FROM photos ORDER BY created_at DESC")
    return render_template("index.html", devices=devices, playlists=playlists, photos=photos)


@app.route("/settings", methods=["GET", "POST"])
def settings_page() -> str | Any:
    if request.method == "POST":
        for section in SETTINGS_FIELDS:
            for field in section["fields"]:
                value = request.form.get(field["key"], "").strip()
                set_setting(field["key"], value)
        flash("Settings saved.", "success")
        return redirect(url_for("settings_page"))

    values = get_all_settings()
    return render_template("settings.html", settings_groups=SETTINGS_FIELDS, values=values)


@app.route("/devices/new", methods=["POST"])
def create_device() -> Any:
    name = request.form.get("name", "").strip()
    location = request.form.get("location", "").strip()
    playlist_id = request.form.get("playlist_id", type=int)
    if not name:
        flash("Device name is required.", "error")
        return redirect(url_for("index"))

    created = now_iso()
    slug = slugify(request.form.get("slug", "").strip() or name)
    try:
        execute(
            """
            INSERT INTO devices (name, slug, location, playlist_id, is_active, last_seen, created_at, updated_at)
            VALUES (?, ?, ?, ?, 1, ?, ?, ?)
            """,
            (name, slug, location or None, playlist_id, created, created, created),
        )
        flash("Device created.", "success")
    except sqlite3.IntegrityError:
        flash("That device slug already exists.", "error")
    return redirect(url_for("index"))


@app.route("/devices/<int:device_id>/delete", methods=["POST"])
def delete_device(device_id: int) -> Any:
    execute("DELETE FROM devices WHERE id = ?", (device_id,))
    flash("Device deleted.", "success")
    return redirect(url_for("index"))


@app.route("/playlists/new", methods=["POST"])
def create_playlist() -> Any:
    name = request.form.get("name", "").strip()
    if not name:
        flash("Playlist name is required.", "error")
        return redirect(url_for("index"))
    created = now_iso()
    execute(
        "INSERT INTO playlists (name, created_at, updated_at) VALUES (?, ?, ?)",
        (name, created, created),
    )
    flash("Playlist created.", "success")
    return redirect(url_for("index"))


@app.route("/playlists/<int:playlist_id>")
def playlist_detail(playlist_id: int) -> str:
    playlist = fetch_one("SELECT * FROM playlists WHERE id = ?", (playlist_id,))
    if not playlist:
        return render_template("not_found.html", message="Playlist not found."), 404
    items = fetch_all(
        "SELECT * FROM playlist_items WHERE playlist_id = ? ORDER BY sort_order, id",
        (playlist_id,),
    )
    photos = fetch_all("SELECT * FROM photos ORDER BY created_at DESC")
    return render_template("playlist_detail.html", playlist=playlist, items=items, photos=photos)


@app.route("/playlists/<int:playlist_id>/items/new", methods=["POST"])
def create_playlist_item(playlist_id: int) -> Any:
    module_type = request.form.get("module_type", "clock").strip()
    title = request.form.get("title", "").strip() or module_type.title()
    duration_seconds = request.form.get("duration_seconds", type=int) or 20
    sort_order = request.form.get("sort_order", type=int) or 0

    config: dict[str, Any] = {}
    if module_type == "clock":
        config = {
            "show_seconds": request.form.get("show_seconds") == "on",
            "show_date": request.form.get("show_date") != "off",
            "timezone": request.form.get("timezone", "America/Chicago").strip() or "America/Chicago",
        }
    elif module_type == "weather":
        config = {
            "latitude": float(request.form.get("latitude", "31.3382") or 31.3382),
            "longitude": float(request.form.get("longitude", "-94.7291") or -94.7291),
            "label": request.form.get("label", "Lufkin, TX").strip() or "Location",
        }
    elif module_type == "custom_text":
        config = {
            "body": request.form.get("body", "").strip(),
            "subtext": request.form.get("subtext", "").strip(),
        }
    elif module_type == "quote":
        quotes_raw = request.form.get("quotes", "").strip()
        quotes = [line.strip() for line in quotes_raw.splitlines() if line.strip()]
        config = {"quotes": quotes or ["Add your own quotes in the admin panel."]}
    elif module_type == "photos":
        photo_ids = request.form.getlist("photo_ids")
        config = {
            "photo_ids": [int(pid) for pid in photo_ids if pid.isdigit()],
            "shuffle": request.form.get("shuffle") == "on",
        }

    created = now_iso()
    execute(
        """
        INSERT INTO playlist_items (
            playlist_id, module_type, title, duration_seconds, sort_order,
            config_json, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            playlist_id,
            module_type,
            title,
            duration_seconds,
            sort_order,
            json.dumps(config),
            created,
            created,
        ),
    )
    flash("Playlist item added.", "success")
    return redirect(url_for("playlist_detail", playlist_id=playlist_id))


@app.route("/playlists/<int:playlist_id>/items/<int:item_id>/delete", methods=["POST"])
def delete_playlist_item(playlist_id: int, item_id: int) -> Any:
    execute("DELETE FROM playlist_items WHERE id = ?", (item_id,))
    flash("Playlist item deleted.", "success")
    return redirect(url_for("playlist_detail", playlist_id=playlist_id))


@app.route("/photos/upload", methods=["POST"])
def upload_photo() -> Any:
    file = request.files.get("photo")
    title = request.form.get("title", "").strip()
    if not file or file.filename == "":
        flash("Please choose a photo.", "error")
        return redirect(url_for("index"))
    if not allowed_file(file.filename):
        flash("Unsupported file type.", "error")
        return redirect(url_for("index"))

    filename = f"{uuid.uuid4().hex}_{secure_filename(file.filename)}"
    save_path = UPLOAD_DIR / filename
    file.save(save_path)
    execute(
        "INSERT INTO photos (title, filename, created_at) VALUES (?, ?, ?)",
        (title or file.filename, filename, now_iso()),
    )
    flash("Photo uploaded.", "success")
    return redirect(url_for("index"))


@app.route("/photos/<int:photo_id>/delete", methods=["POST"])
def delete_photo(photo_id: int) -> Any:
    photo = fetch_one("SELECT * FROM photos WHERE id = ?", (photo_id,))
    if photo:
        path = UPLOAD_DIR / photo["filename"]
        if path.exists():
            path.unlink()
        execute("DELETE FROM photos WHERE id = ?", (photo_id,))
        flash("Photo deleted.", "success")
    return redirect(url_for("index"))


@app.route("/device/<slug>")
def device_view(slug: str) -> str:
    device = fetch_one(
        """
        SELECT d.*, p.name AS playlist_name
        FROM devices d
        LEFT JOIN playlists p ON p.id = d.playlist_id
        WHERE d.slug = ? AND d.is_active = 1
        """,
        (slug,),
    )
    if not device:
        return render_template("not_found.html", message="Device not found."), 404

    execute(
        "UPDATE devices SET last_seen = ?, updated_at = ? WHERE id = ?",
        (now_iso(), now_iso(), device["id"]),
    )
    return render_template("device_view.html", device=device)


@app.route("/api/device/<slug>")
def device_payload(slug: str) -> Any:
    device = fetch_one(
        "SELECT * FROM devices WHERE slug = ? AND is_active = 1",
        (slug,),
    )
    if not device:
        return jsonify({"error": "Device not found"}), 404

    items = fetch_all(
        "SELECT * FROM playlist_items WHERE playlist_id = ? ORDER BY sort_order, id",
        (device["playlist_id"],),
    )
    payload_items = []
    for item in items:
        config = json_loads_safe(item["config_json"], {})
        payload: dict[str, Any] = {
            "id": item["id"],
            "module_type": item["module_type"],
            "title": item["title"],
            "duration_seconds": item["duration_seconds"],
            "config": config,
        }
        if item["module_type"] == "quote":
            quotes = config.get("quotes", [])
            payload["config"]["selected_quote"] = random.choice(quotes) if quotes else ""
        if item["module_type"] == "photos":
            photo_ids = config.get("photo_ids", [])
            photos = []
            if photo_ids:
                placeholders = ",".join("?" for _ in photo_ids)
                query = f"SELECT * FROM photos WHERE id IN ({placeholders}) ORDER BY id"
                photos = fetch_all(query, tuple(photo_ids))
            if not photos:
                photos = fetch_all("SELECT * FROM photos ORDER BY created_at DESC")
            photo_payload = [
                {
                    "id": photo["id"],
                    "title": photo["title"],
                    "url": url_for("uploaded_file", filename=photo["filename"]),
                }
                for photo in photos
            ]
            if config.get("shuffle"):
                random.shuffle(photo_payload)
            payload["config"]["photos"] = photo_payload
        payload_items.append(payload)

    execute(
        "UPDATE devices SET last_seen = ?, updated_at = ? WHERE id = ?",
        (now_iso(), now_iso(), device["id"]),
    )

    return jsonify(
        {
            "device": {
                "name": device["name"],
                "slug": device["slug"],
                "location": device["location"],
            },
            "items": payload_items,
            "generated_at": now_iso(),
        }
    )


@app.route("/uploads/<path:filename>")
def uploaded_file(filename: str) -> Any:
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename)


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=8008, debug=True)
